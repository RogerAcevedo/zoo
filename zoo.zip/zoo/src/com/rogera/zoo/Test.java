package com.rogera.zoo;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		// GORILLA
//		Gorilla silverback = new Gorilla();
//		
//		silverback.throwSomething();
//		silverback.throwSomething();
//		silverback.throwSomething();
//		
//		silverback.eatBananas();
//		silverback.eatBananas();
//		
//		silverback.climb();
		
		
		// BAT
		Bat zubat = new Bat();
		
		zubat.attackTown();
		zubat.attackTown();
		zubat.attackTown();
		
		zubat.eatHumans();
		zubat.eatHumans();
		
		zubat.fly();
		zubat.fly();
		
		//System.out.println("Hey, I am a pokemon" + " " + silverback.displayEnergy());
	
	}

}
